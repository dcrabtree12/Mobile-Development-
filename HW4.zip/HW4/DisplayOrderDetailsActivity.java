package com.example.mypizzaapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class DisplayOrderDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_order_details);
        Intent intent = getIntent();

        // retrieve value of pizza size
        String pizza_size = intent.getStringExtra("pizzaSize");
        TextView t1 = (TextView)findViewById(R.id.tvPizzaSize);
        t1.setText("Pizza size: " + pizza_size);

        // retrieve value of pizza crust
        String pizza_crust = intent.getStringExtra("pizzaCrust");
        TextView t2 = (TextView)findViewById(R.id.tvPizzaCrust);
        t2.setText("Pizza crust: " + pizza_crust);

        // retrieve value of checkboxes
        String pizza_toppings = intent.getStringExtra("CheckBox");
        TextView t3 = (TextView)findViewById(R.id.tvCheckBox);
        t3.setText("Toppings: " + pizza_toppings + "");

        // retrieve value for order details
        String order_Detail = intent.getStringExtra("pickOrDeliver");
        TextView t4 = (TextView)findViewById(R.id.tvOrderDetail);
        t4.setText("Thank you for deciding to order your pizza as a " + order_Detail + "!");
    }
}
