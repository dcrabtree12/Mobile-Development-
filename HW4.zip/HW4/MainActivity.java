package com.example.mypizzaapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.rbSmall:
                if (checked)
                    // Small
                    Toast.makeText(getApplicationContext(),
                            "Small", Toast.LENGTH_SHORT).show();
                break;
            case R.id.rbMedium:
                if (checked)
                    // Medium
                    Toast.makeText(getApplicationContext(),
                            "Medium", Toast.LENGTH_SHORT).show();
                break;
            case R.id.rbLarge:
                if (checked)
                    // Large
                    Toast.makeText(getApplicationContext(),
                            "Large", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    public void sendOrder(View view) {
        // Do something in response to button
        RadioGroup radioSizeGroup, radioOrderGroup;
        RadioButton radioSizeButton, radioOrderButton;

        // get selected radio button from radioGroup
        radioSizeGroup = findViewById(R.id.radioSize);
        radioOrderGroup = findViewById(R.id.radioOrder);

        int selectedId = radioSizeGroup.getCheckedRadioButtonId();
        int selectedIdTwo = radioOrderGroup.getCheckedRadioButtonId();

        // find the radio button by returned id
        radioSizeButton = findViewById(selectedId);
        radioOrderButton = findViewById(selectedIdTwo);

        // retrieve the value of the text attribute and pass it to the next activity
        CharSequence szSize = radioSizeButton.getText();
        CharSequence orderDetail = radioOrderButton.getText();

        // retrieve details of pizza toppings
        String pizzaToppings = "";

        CheckBox myCheckBox1 = findViewById(R.id.checkBox);
        CheckBox myCheckBox2 = findViewById(R.id.checkBox2);
        CheckBox myCheckBox3 = findViewById(R.id.checkBox3);

        if (myCheckBox1.isChecked()) {
            pizzaToppings += "(" + myCheckBox1.getText().toString() + ")";
        }
        if (myCheckBox2.isChecked()) {
            pizzaToppings += "(" + myCheckBox2.getText().toString() + ")";
        }
        if (myCheckBox3.isChecked()) {
            pizzaToppings += "(" + myCheckBox3.getText().toString() + ")";
        }

        // retrieve value of spinner
        Spinner mySpinner = findViewById(R.id.spinner);
        TextView textSel = (TextView) mySpinner.getSelectedView();
        String szCrust = textSel.getText().toString();

        Intent intent = new Intent(this, DisplayOrderDetailsActivity.class);

        intent.putExtra("pizzaSize", szSize);
        intent.putExtra("pizzaCrust", szCrust);
        intent.putExtra("CheckBox", pizzaToppings);
        intent.putExtra("pickOrDeliver", orderDetail);
        startActivity(intent);
    }
}
