package com.example.rememberme;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    /**
     * Called when the user clicks the button
     */
    public void sendLogin(View view) {
        // Do something in response to button
        CheckBox rememberMe = ((CheckBox) findViewById(R.id.checkBox));

        if (rememberMe.isChecked()) {
            Toast.makeText(getApplicationContext(),
                    "Button clicked, Remember me!", Toast.LENGTH_LONG).show();

            // Retrieve the entered value
            EditText editText = (EditText) findViewById(R.id.editText);
            String enteredName = editText.getText().toString();

            // Access shared preferences
            SharedPreferences myPrefs = getPreferences(Context.MODE_PRIVATE);

            // Save the value to shared preferences
            SharedPreferences.Editor editor = myPrefs.edit();
            editor.putString("User name", enteredName);
            editor.commit();

        } else {
            Toast.makeText(getApplicationContext(),
                    "Button clicked, Don't remember me!",
                    Toast.LENGTH_LONG).show();
        }
    }

        /** Called when the user taps the Read button */
    public void readLogin (View view) {
        // Access shared preferences
        SharedPreferences myPrefs = getPreferences(Context.MODE_PRIVATE);

        // Read the value from shared preferences
        String retrievedName = myPrefs.getString("User name", null);

        // Display the retrieved name in the EditText editText2
        EditText editText = (EditText) findViewById(R.id.editText);
        editText.setText(retrievedName);
    }
}
