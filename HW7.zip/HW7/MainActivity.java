package com.example.storage;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
    private static final String Filename  = "example.txt";

    EditText Text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text = findViewById(R.id.editText);
    }

    /** Called when the user taps Save File */
    public void sendFile(View view) {

        // Retrieve the entered value
        String text = Text.getText().toString();
        FileOutputStream outputStream;

        // Access shared preferences
        SharedPreferences myPrefs = getPreferences(Context.MODE_PRIVATE);

        // Save the value to shared preferences
        SharedPreferences.Editor editor = myPrefs.edit();
        editor.putString("input", text);
        editor.commit();

            try {
                outputStream = openFileOutput(Filename, MODE_PRIVATE);
                outputStream.write(text.getBytes());

                Text.getText().clear();
                Toast.makeText(getApplicationContext(),
                        "File Saved!" + getFilesDir() + "/" + Filename, Toast.LENGTH_LONG).show();

                outputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
    }

    /** Called when the user taps Read File */
    public void readFile (View view) {

        FileInputStream inputStream;

            try {
                inputStream = openFileInput(Filename);
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream);
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                StringBuilder stringBuild = null;
                //String text = new String();

                // Access shared preferences
                SharedPreferences myPrefs = getPreferences(Context.MODE_PRIVATE);

                // Read the value from shared preferences
                String retrievedName = myPrefs.getString("input", null);

                // Display the retrieved name in the EditText editText2
                EditText editText2 = (EditText) findViewById(R.id.editText);
                editText2.setText(retrievedName);

                getFilesDir();
                Toast.makeText(getApplicationContext(),
                        "File Read!" + getFilesDir() + "/" + Filename, Toast.LENGTH_LONG).show();

                Text.setText(stringBuild.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
    }
}
